import { handlers } from "@/app/nextAuth";

export const {GET, POST} = handlers